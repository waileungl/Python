import parent
# in the same file, add the following below the User class
print(__name__)
print(parent.userAnna.say_hello())